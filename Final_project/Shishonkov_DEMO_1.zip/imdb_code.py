def get_actors_by_movie_soup(cast_page_soup, num_of_actors_limit=None):
    actors = cast_page_soup.find('table', attrs={'class': 'cast_list'}).find_all('a')
    actors_list = []
    if num_of_actors_limit is None:
        for act in range(1, len(actors), 3):
            actors_list.append((actors[act].text.strip(),
                                ''.join(['https://www.imdb.com', actors[act]['href']])))
    else:
        for act in range(1, 3 * num_of_actors_limit, 3):
            actors_list.append((actors[act].text.strip(),
                                ''.join(['https://www.imdb.com', actors[act]['href']])))
    return actors_list


def get_movies_by_actor_soup(actor_page_soup, num_of_movies_limit=None):
    all_movies = actor_page_soup\
                        .find('div', attrs={'class': 'filmo-category-section'})\
                        .find_all('div', class_='filmo-row')
    movie = []
    for mov in range(len(all_movies)):
        if all_movies[mov].contents[4] == '\n':
            movie.append((all_movies[mov].contents[3].text,
                          ''.join(['https://www.imdb.com',
                                   list(all_movies[mov].contents[3].children)[0]['href']])))
    if num_of_movies_limit is None:
        return movie
    return movie[:num_of_movies_limit]
