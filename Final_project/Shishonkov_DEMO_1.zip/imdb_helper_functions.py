def helper_function_example():
    return 'Hello, I am a supposed to be a helper function'
